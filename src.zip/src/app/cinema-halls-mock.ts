import { CinemaHall } from './CinemaHall';

const cinemaHalls: CinemaHall[] = [];

let c = new CinemaHall(5,10);
cinemaHalls.push(c);
c = new CinemaHall(5,10);
cinemaHalls.push(c);
c = new CinemaHall(5,10);
cinemaHalls.push(c);
c = new CinemaHall(5,10);
cinemaHalls.push(c);
c = new CinemaHall(5,10);
cinemaHalls.push(c);
c = new CinemaHall(5,10);
cinemaHalls.push(c);
c = new CinemaHall(5,10);
cinemaHalls.push(c);
c = new CinemaHall(5,10);
cinemaHalls.push(c);
c = new CinemaHall(5,10);
cinemaHalls.push(c);
c = new CinemaHall(5,10);
cinemaHalls.push(c);

export const CinemaHalls = cinemaHalls;