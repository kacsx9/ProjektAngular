import { Component } from '@angular/core';
import { FilmShowsComponent } from './film-shows/film-shows.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'FilmShow List';
}
