export class Film {

    constructor(public title: string, public genre: string, public filmWebLink: string) {

    }
}